﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ficha_1
{
    public class Forma
    {
        public ConsoleColor Cor { get; set; }
        public Forma(ConsoleColor cor)
        {
            Cor = cor;
        }
    }
}

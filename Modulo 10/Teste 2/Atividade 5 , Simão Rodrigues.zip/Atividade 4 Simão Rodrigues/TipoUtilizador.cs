﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoBiblioteca
{
    public enum TipoUtilizador
    {
        Nulo = 0,
        Útilizador,
        Admistrador

    }

}
